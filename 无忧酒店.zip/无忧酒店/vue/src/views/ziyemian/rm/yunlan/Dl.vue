<template>
  <div class="home" data-spy="scroll">
<div id="wrap_index"> <!-- 侧边导航 -->

<div class="class page-prev visible-xs visible-sm">
  <div class="close"></div>
  <div class="class-top">
    <form name="formsearch" action="/plus/search.php">
      <input type="hidden" name="kwtype" value="0">
      <input type="text" class="txt1" name="q" value="请输入关键字">
      <input type="submit" class="btn1" value="">
    </form>
  </div>
  <div class="class-m">
   <ul class="nnav">
            <li>
              <!-- <a href="../../../13097.html" class="ce">网站首页</a> -->
              <router-link to="/home" class="ce">网站首页</router-link>
            </li>
            <li class="menu_head">
              <router-link to="/guanyuwomen" class="ce">关于我们</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../zhutilvyou/Index.html" class="ce">主题旅游</a> -->
              <router-link to="/zhutilvyou" class="ce">主题旅游</router-link>
              <ul class="menu_body">
                <li>
                  <router-link to="/zhutilvyou" class="er"
                    >国内游</router-link
                  >
                </li>

                <li>
                  <router-link to="/cjy1" class="er"
                    >出境游</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../remenmudedi/Index.html" class="ce">热门目的地</a> -->
       <router-link to="/remenmudedi" class="ce">热门目的地</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/yn" class="er">云南</router-link>
                </li>

                <li>
                  <router-link to="/sc" class="er"
                    >四川</router-link
                  >
                </li>

                <li>
                  <router-link to="/fj" class="er">福建</router-link>
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../xinwenzixun/Index.html" class="ce">新闻资讯</a> -->
              <router-link to="/xnwenzixun" class="ce">新闻资讯</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../shushijiudian/Index.html" class="ce">舒适酒店</a> -->
              <router-link to="/shushijiudian" class="ce">舒适酒店</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/srj" class="er"
                    >双人间</router-link
                  >
                </li>

                <li>
                  <router-link to="/drj" class="er"
                    >单人间</router-link
                  >
                </li>

                <li>
                  <router-link
                    to="/zttf"
                    class="er"
                    >总统套房</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../lianxiwomen/Index.html" class="ce">联系我们</a> -->
              <router-link to="/lianxiwomen" class="ce">联系我们</router-link>

              <ul class="menu_body"></ul>
            </li>
          </ul>
  </div>
</div>
<div class="opacity2"></div>
<div id="header" class="head visible-lg visible-md">
  <div class="container-fluid">
    <div class="logo wow fadeInLeft col-md-3"><router-link to="/home"><img src="../../../../static/picture/logo.png"></router-link></div>
    <div class="col-md-9" style="height: 56px;">
      <div class="search col-md-3 wow fadeInRight" style="float: right;">
        <form name="formsearch" action="/plus/search.php">
          <input type="hidden" name="kwtype" value="0">
          <input class="txt1" type="text" name="q" placeholder="请输入关键字">
          <input class="btn1" type="submit" value="">
        </form>
      </div>
      <div class="col-md-9 nav wow fadeInDown navbar-nav nav_box" style="float: right; text-align: right;">
        <div class="yiji current"><router-link to="/home">首页</router-link ></div>
        <div class="yiji"><router-link to="/guanyuwomen"><em>关于我们</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/zhutilvyou"><em>主题旅游</em></router-link >
          <div class="libox">
             <router-link to="/zhutilvyou"><em>国内游</em></router-link>  <router-link to="/cjy1"><em>出境游</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/remenmudedi"><em>热门目的地</em></router-link >
          <div class="libox">
             <router-link to="/yn"><em>云南</em></router-link>  <router-link to="/sc"><em>四川</em></router-link>  <router-link to="/fj"><em>福建</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/xnwenzixun"><em>新闻资讯</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/shushijiudian"><em>舒适酒店</em></router-link >
          <div class="libox">
             <router-link to="/srj"><em>双人间</em></router-link>  <router-link to="/drj"><em>单人间</em></router-link>  <router-link to="/zt"><em>总统套房</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/lianxiwomen"><em>联系我们</em></router-link >
          <div style="display:none">
             </div>
        </div> </div>
    </div>
  </div>
</div>
<div id="molheader" class="visible-sm visible-xs">
  <div class="logomol"><router-link to="/home"><img src="../../../../static/picture/logo.png"></router-link></div>
  <div class="mol_navbutton"><img src="../../../../static/picture/menu.png"></div>
</div>
 
  <!-- pcbanner -->
  <div id="myCarousel1" class="carousel slide visible-md visible-lg">
    <div class="carousel-inner">
      <div class="item active"> <a><img src="../../../../static/picture/b.jpg"><em></em></a> </div>
    </div>
  </div>
  <!-- 手机banner -->
  <div id="molbanner" class="visible-xs visible-sm">
    <div class="swiper-container swiper-banner">
      <ul class="swiper-wrapper banner-img">
        <li class="swiper-slide"><a class="pic"><img src="../../../../static/picture/b.jpg"></a></li>
      </ul>
    </div>
  </div>
  <div class="inner_main">
    <div class="ny_cont">
      <div class="nyttweizhi">
        <div class="nytitle agdollar wow fadeInLeft">
          <h2>热门目的地</h2>
          <p>DESTINATIONS</p>
        </div>
        <div class="weizhi visible-md visible-lg"><router-link to='/home'>主页</router-link> > <router-link to=''>热门目的地</router-link> > <router-link to=''>云南</router-link>  > </div>
        <a href="javascript:;" class="classfiy visible-sm visible-xs">分类 +</a> </div>
      <div class="navs">
        <ul class="mtree transit">
          <li><a href='Index.html' class='thisclass'>云南<em></em></a></li>
          <li><a href='../sichuan/Index.html'>四川<em></em></a></li>
          
          <li><a href='../fujian/Index.html'>福建<em></em></a></li>
          
        </ul>
      </div>
      <div class="wrap_page wrap_page1">
        <div class="page_content page_content1">
          <div class="newsdet1 prodetailwrap">
            <div class="clearfix prodw">
              <div class="prodetail_gd col-md-6 col-xs-12 col-sm-12">
                <div class="swiper-container gallery-top">
                  <div class="swiper-wrapper"> <div class="swiper-slide proimg"><img src="../../../../static/picture/1-1Z10G05911.jpg"></div><div class="swiper-slide proimg"><img src="../../../../static/picture/1-1Z10G05914.jpg"></div> </div>
                  <div class="swiper-button-next swiper-button-white"></div>
                  <div class="swiper-button-prev swiper-button-white"></div>
                </div>
                <div class="swiper-container gallery-thumbs">
                  <div class="swiper-wrapper"> <div class="swiper-slide">
                      <div class="pimg"><img src="../../../../static/picture/1-1Z10G05911.jpg"><em></em></div>
                    </div><div class="swiper-slide">
                      <div class="pimg"><img src="../../../../static/picture/1-1Z10G05914.jpg"><em></em></div>
                    </div> </div>
                </div>
                <!-- Add Arrows --> 
                
              </div>
              <div class="prodetail_nr col-md-6 col-xs-12 col-sm-12">
                <div class="scroll_dt" style="text-align:left">
                  <h2 class="title">大理古城</h2>
                  <div class="info">
                    <p style="margin-left:28px">线路编号： </p>
                    <p class="p1">线路亮点 </p>
                  </div>
                  <div class="price"> <em></em><span>￥<i>199</i>起/人</span> </div>
                  <div class="time"> <em>出发城市： </em> </div>
                  <button @click="jian()" class="btnjian">－</button>
                     {{zs}}
                        <button @click="jia" class="btnjia">＋</button><br>
                         需支付：<span class="zj"> {{rmb*zs}} 
                      </span>元

                  <div class="order"><a href="" class="buy">天猫购买</a><em><i>在线电话:020-66888888</i></em></div>
                </div>
              </div>
            </div>
            
          </div>
          <div class="ny_content ny_content1">
            <div id="tabBox1" class="tabBox">
              <div class="hd">
                <ul>
                  <li><a href="javascript:;" @click="msg=0" :class="{'cur':msg===0}">行程线路</a></li>
                  <li><a href="javascript:;" @click="msg=1" :class="{'cur':msg===1}">行程攻略</a></li>
                  <li><a hhref="javascript:;" @click="msg=2" :class="{'cur':msg===2}"  >预定须知</a></li>
                  <li><a href="javascript:;" @click="msg=3" :class="{'cur':msg===3}" >费用说明 </a></li>
                </ul>
              </div>
              <div class="bd" id="tabBox1-bd"><!-- 添加id，js用到 -->
                <div class="con" v-show="msg===0"><!-- 高度自适应需添加外层 -->
                  <ul>
                    <p><span ><p>
	可选择深圳湾口岸直通巴士！</p>
<p>
	下车点：太子 &nbsp; 旺角 &nbsp; 佐敦 &nbsp; 尖沙咀圆方 &nbsp; 荃湾 &nbsp; 黄大仙 &nbsp;油塘 &nbsp;观塘 &nbsp;沙田 &nbsp;坑口 &nbsp;牛头角，尖沙咀尖东</p>
<p>
	上环 &nbsp;中环 &nbsp;湾仔 &nbsp;铜锣湾</p>
<ul style="box-sizing: border-box; margin: 0px; padding-right: 0px; padding-left: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;; font-size: 14px;">
</ul>
</span></p>
                  </ul>
                </div>
                <div class="con" v-show="msg===1"><!-- 高度自适应需添加外层 -->
                  <ul>
                    <p>厦门方特梦幻王国景区是一个以高科技为主要表现形式的文化科技主题公园。坐落于美丽的海滨古城厦门市同安区，公园占地面积约1400亩，是由深圳华强集团投资25亿元兴建的大型高科技第四代主题公园。其最大特点是以科幻和互动体验为最大特色，将动漫卡通、电影特技等国际时尚娱乐元素与中国传统文化符号巧妙融合，创造出充满幻想和创意的神奇天地，被誉为&ldquo;东方梦幻乐园&rdquo;、&ldquo;亚洲科幻神奇&rdquo;。 这个总投资50亿元的世界一流文化科技产业项目，堪称&ldquo;中国迪斯尼&rdquo;占地面积1320亩，游乐项目多，科技含量高，参与互动性强，为游客提供全新体验和享受。预计年接待游客量600万人次，每年可为厦门新增旅游收入25亿元。 景区包含27大项主题项目区、200多个项目，其中大部分为室内高科技体验项目， 游玩不受气候影响，无论春夏秋冬，无论风霜雨雪，公园均能照常开放营业。此外，园区内项目还充分考虑到各个年龄阶层的需求，绝大多数项目老少皆宜，非常适合家庭旅游和周末休闲游乐。</p>
                  </ul>
                </div>
                <div class="con" v-show="msg===2"><!-- 高度自适应需添加外层 -->
                  <ul>
                    <p><p>
	1）一张身份证每天（同一出游日期）最多订购5张票 ，超过5张请换身份证另外下单。</p>
<p>
	34）游乐项目如有变动，以当日公告为准。所有游乐项目均会定期进行日检、周检和年度检修，相关检修工作可能会造成部分游乐项目运行时间的延迟或暂停对游客开放，详情以项目现场公告为准。</p>
<p>
	6）冰雪世界为新的体验项目，需要租借羽绒服才能进去</p>

                  </ul>
                </div>
                <div class="con" v-show="msg===3"><!-- 高度自适应需添加外层 -->
                  <ul>
                    <p>开放时间：9:30-17:30（周一-周五），9:30-18:00（周六、周日、节假日及7、8月）</p>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="hotaren">
            <div class="title">热门目的地<router-link to="/remenmudedi">查看更多</router-link></div>
            <ul class="clearfix">
              <li class="col-md-3 col-sm-6 col-xs-12"> <router-link to="/ls"> <i><img src="../../../../static/picture/1-1Z10G059480-L.jpg"><span>Gulangyu</span></i>
                <h2>四川</h2>
                <p>乐山大佛</p>
                </router-link> </li>
<li class="col-md-3 col-sm-6 col-xs-12"> <router-link to="/jzg"> <i><img src="../../../../static/picture/1-1Z10G100110-L.jpg"><span>Jiuzhaigou</span></i>
                <h2>四川</h2>
                <p>九寨沟</p>
                </router-link> </li>
<li class="col-md-3 col-sm-6 col-xs-12"> <router-link to="/hlg"> <i><img src="../../../../static/picture/1-1Z10G100350-L.jpg"><span>Hailuogou</span></i>
                <h2>四川</h2>
                <p>海螺沟</p>
                </router-link> </li>
<li class="col-md-3 col-sm-6 col-xs-12"> <router-link to="/yl"> <i><img src="../../../../static/picture/1-1Z10G05G90-L.jpg"><span>Snow Mountain</span></i>
                <h2>云南</h2>
                <p>玉龙雪山</p>
                </router-link> </li>

            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="footbg clearfix">
  <div class="footwrap col-md-11">
    <div class="logofriendly clearfix">
      <div class="footlogo col-sm-12 col-xs-12 col-md-2 block" data-move-x="-100px" style="opacity: 0; transform: translateX(-100px);"><img src="../../../../static/picture/logo.png"></div>
      <div class="footnav col-sm-12 col-xs-12 col-md-8 block" data-move-x="-100px" style="opacity: 0; transform: translateX(-100px);">友情链接：        </div>
    </div>
    <div class="copyright clearfix">
      <p class="p1">Copyright &copy; 2020 某某旅游有限公司 版权所有
        </p>
      <!--<p class="p2">技术支持：<a href="http://www.dede58.cn/"> 58</a></p>--> 
    </div>
  </div>
  <div class="winxin col-md-1 visible-lg visible-md"> <i><img src="../../../../static/picture/weixin.png"></i>
    <h2></h2>
  </div>
</div>
 </div>
  </div>
</template>






<script>

export default {
  data(){
    return{
      zs:'1',
      rmb:`348`,
       msg: 0
    }
  },
  methods:{
    
     jia(zs) {
　　
      　　this.zs++
　　},
      jian(zs) {
        if(this.zs>1)
                    this.zs--;
                },  
                buy(){
                  alert(`购买成功${this.zs}人票,共消费${this.rmb*this.zs}元`)
                }  
                  
                 
  },

  
}
</script>
  
  
  
<style scoped>
@import "../../../../static/css/animate.css";
@import "../../../../static/css/style.css";
@import "../../../../static/css/swiper-3.3.1.min.css";
@import "../../../../static/css/bootstrap.min.css";
.zj{

  margin-top: 20px;
  color:#FF7418;
  font-size: 24px;

}

.btnjian{
  margin-top: 15px;
}
.btnjian,.btnjia{
   border: none;
  outline: none;
   line-height: 1.499;
    position: relative;
    display: inline-block;
    font-weight: 400;
    white-space: nowrap;
    text-align: center;
    background-image: none;
    border: 1px solid transparent;
    -webkit-box-shadow: 0 2px 0 rgba(0,0,0,0.015);
    box-shadow: 0 2px 0 rgba(0,0,0,0.015);
    cursor: pointer;
    -webkit-transition: all .3s cubic-bezier(.645, .045, .355, 1);
    transition: all .3s cubic-bezier(.645, .045, .355, 1);
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    height: 32px;
    padding: 0 15px;
    font-size: 14px;
    border-radius: 4px;
    color: rgba(0,0,0,0.65);
    background-color: #fff;
    border-color: #d9d9d9;
    
}
</style>