<template>
  <div data-spy="scroll">
    <div class="class page-prev visible-xs visible-sm">
      <div class="close"></div>
      <div class="class-top">
        <form name="formsearch" action="/plus/search.php">
          <input type="hidden" name="kwtype" value="0" />
          <input type="text" class="txt1" name="q" value="请输入关键字" />
          <input type="submit" class="btn1" value="" />
        </form>
      </div>
      <div class="class-m">
       <ul class="nnav">
            <li>
              <!-- <a href="../../../13097.html" class="ce">网站首页</a> -->
              <router-link to="/home" class="ce">网站首页</router-link>
            </li>
            <li class="menu_head">
              <router-link to="/guanyuwomen" class="ce">关于我们</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../zhutilvyou/Index.html" class="ce">主题旅游</a> -->
              <router-link to="/zhutilvyou" class="ce">主题旅游</router-link>
              <ul class="menu_body">
                <li>
                  <router-link to="/zhutilvyou" class="er"
                    >国内游</router-link
                  >
                </li>

                <li>
                  <router-link to="/cjy1" class="er"
                    >出境游</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../remenmudedi/Index.html" class="ce">热门目的地</a> -->
       <router-link to="/remenmudedi" class="ce">热门目的地</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/yn" class="er">云南</router-link>
                </li>

                <li>
                  <router-link to="/sc" class="er"
                    >四川</router-link
                  >
                </li>

                <li>
                  <router-link to="/fj" class="er">福建</router-link>
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../xinwenzixun/Index.html" class="ce">新闻资讯</a> -->
              <router-link to="/xnwenzixun" class="ce">新闻资讯</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../shushijiudian/Index.html" class="ce">舒适酒店</a> -->
              <router-link to="/shushijiudian" class="ce">舒适酒店</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/srj" class="er"
                    >双人间</router-link
                  >
                </li>

                <li>
                  <router-link to="/drj" class="er"
                    >单人间</router-link
                  >
                </li>

                <li>
                  <router-link
                    to="/zttf"
                    class="er"
                    >总统套房</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../lianxiwomen/Index.html" class="ce">联系我们</a> -->
              <router-link to="/lianxiwomen" class="ce">联系我们</router-link>

              <ul class="menu_body"></ul>
            </li>
          </ul>
  </div>
</div>
    <div class="opacity2"></div>
    <div id="header" class="head visible-lg visible-md">
      <div class="container-fluid">
        <div class="logo wow fadeInLeft col-md-3">
          <a href="../../../13097.html"
            ><img src="../../../static/picture/logo.png"
          /></a>
        </div>
        <div class="col-md-9" style="height: 56px">
          <div class="search col-md-3 wow fadeInRight" style="float: right">
            <form name="formsearch" action="/plus/search.php">
              <input type="hidden" name="kwtype" value="0" />
              <input
                class="txt1"
                type="text"
                name="q"
                placeholder="请输入关键字"
              />
              <input class="btn1" type="submit" value="" />
            </form>
          </div>
          <div
            class="col-md-9 nav wow fadeInDown navbar-nav nav_box"
            style="float: right; text-align: right"
          >
            <div class="yiji current">
              <router-link to="/">首页</router-link>
            </div>
            <div class="yiji">
              <router-link to="/guanyuwomen"><em>关于我们</em></router-link>
              <div style="display: none"></div>
            </div>
            <div class="yiji">
              <router-link to="/zhutilvyou"><em>主题旅游</em></router-link>
              <div class="libox">
                <a href="a/zhutilvyou/guonayou/Index.html"><em>国内游</em></a>
                <a href="a/zhutilvyou/chujingyou/Index.html"><em>出境游</em></a>
              </div>
            </div>
            <div class="yiji">
              <router-link to="/remenmudedi"><em>热门目的地</em></router-link>
              <div class="libox">
                <a href="a/remenmudedi/yunnan/Index.html"><em>云南</em></a>
                <a href="a/remenmudedi/sichuan/Index.html"><em>四川</em></a>
                <a href="a/remenmudedi/fujian/Index.html"><em>福建</em></a>
              </div>
            </div>
            <div class="yiji">
              <router-link to="/xiwenzixun"><em>新闻资讯</em></router-link>
              <div style="display: none"></div>
            </div>
            <div class="yiji">
              <router-link to="/shushijiudian"><em>舒适酒店</em></router-link>
              <div class="libox">
                <a href="a/shushijiudian/shuangrenjian/Index.html"
                  ><em>双人间</em></a
                >
                <a href="a/shushijiudian/danrenjian/Index.html"
                  ><em>单人间</em></a
                >
                <a href="a/shushijiudian/zongtongtaofang/Index.html"
                  ><em>总统套房</em></a
                >
              </div>
            </div>
            <div class="yiji">
              <router-link to="/lianxiwomen"><em>联系我们</em></router-link>
              <div style="display: none"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="molheader" class="visible-sm visible-xs">
      <div class="logomol">
        <a href="../../../13097.html"
          ><img src="../../../static/picture/logo.png"
        /></a>
      </div>
      <div class="mol_navbutton">
        <img src="../../../static/picture/menu.png" />
      </div>
    </div>

    <!-- pcbanner -->
    <div id="myCarousel1" class="carousel slide visible-md visible-lg">
      <div class="carousel-inner">
        <div class="item active">
          <a><img src="../../../static/picture/b.jpg" /><em></em></a>
        </div>
      </div>
    </div>
    <!-- 手机banner -->
    <div id="molbanner" class="visible-xs visible-sm">
      <div class="swiper-container swiper-banner">
        <ul class="swiper-wrapper banner-img">
          <li class="swiper-slide">
            <a class="pic"><img src="../../../static/picture/b.jpg" /></a>
          </li>
        </ul>
      </div>
    </div>

    <div class="wrap_page wrap_page1">
      <div class="page_content page_content1">
        <div class="newdtedit">
          <h2 class="tt">{{ lll.theme }}</h2>
          <p class="time">{{ lll.dates }}</p>
          <p>{{ lll.detalis_1 }}</p>
          <h4>{{ lll.title_1 }}</h4>
          <img :src="lll.img_1" >
          <p>{{ lll.detalis_2 }}</p>
          <h4>{{ lll.title_2 }}</h4>
          <img :src="lll.img_2" >
          <p>{{ lll.detalis_3 }}</p>
          <h4>{{ lll.title_3 }}</h4>
          <img :src="lll.img_3" >
          <p>{{ lll.detalis_4 }}</p>
          <p>{{ lll.detalis_5 }}</p>
          <div>&nbsp;</div>
        </div>
        <div class="other clearfix">
        
          <!-- <a
            href="javascript:history.go(-1)"
            class="return visible-md visible-lg"
            >返回</a
          > -->
         <button @click="goback" class="btn">查看更多新闻资讯</button>
        </div>
      </div>
    </div>
  </div>
</template>
<style scoped>
.newdtedit h4{
  font-weight: bold;
 text-align: left;
}
.clearfix .btn{
 width: 80%;
 
}
</style>
<script>
export default {
  data() {
    return {
      did:"",
      lll: "",
      lll_x:"",
      lll_s:""
    };
  },
  methods:{
goback(){
   this.$router.go(-1)
}
  },
  mounted() {
    let id = this.$route.query.id;
    let did=id
    this.axios.get("/xinwemxiangqing?id=" + id).then((res) => {
      this.lll = res.data.data[0];
      // console.log(this.lll);
    });
    //    this.axios.get('/xinwen').then((reslult)=>{
    //   console.log(reslult.data.data[id])
    //   if(reslult.data.data[id-2]!=undefined){
    //     this.lll_s=reslult.data.data[id-2].theme
    //   }else{
    //      this.lll_s="已经没有更多新闻了"
    //   };
    //  if(reslult.data.data[id]!=undefined){
    //     this.lll_s=reslult.data.data[id].theme
    //   }else{
    //      this.lll_s="已经没有更多新闻了"
    //   };
    // })
  
  },
};
</script>>