import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Guanyuwomen from '../views/Guanyuwomen.vue'
import Lianxiwomen from '../views/Lianxiwomen.vue'
import Remenmudedi from '../views/Remenmudedi.vue'
import Shushijiudian from '../views/Shushijiudian.vue'
import Xnwenzixun from '../views/Xnwenzixun.vue'
import Zhutilvyou from '../views/Zhutilvyou.vue'

//热门目的地子页面
import Ls from '../views/ziyemian/rm/sicuan/Ls.vue'
import Jzg from '../views/ziyemian/rm/sicuan/Jzg.vue'
import Hlg from '../views/ziyemian/rm/sicuan/Hlg.vue'
import Sc from '../views/ziyemian/rm/sicuan/Sc.vue'
import Yl from '../views/ziyemian/rm/yunlan/Yl.vue'
import Eh from '../views/ziyemian/rm/yunlan/Eh.vue'
import Dl from '../views/ziyemian/rm/yunlan/Dl.vue'
import Yn from '../views/ziyemian/rm/yunlan/Yn.vue'
import Fj from '../views/ziyemian/rm/fujian/Fj.vue'


//舒适酒店子页面
import Drj from '../views/ziyemian/ssjd/danrenjian/Drj.vue'
import Srj from '../views/ziyemian/ssjd/shuangrenjian/Srj.vue'
import Fone from '../views/ziyemian/ssjd/shuangrenjian/Fone.vue'
import F2 from '../views/ziyemian/ssjd/shuangrenjian/F2.vue'
import F3 from '../views/ziyemian/ssjd/shuangrenjian/F3.vue'
import F4 from '../views/ziyemian/ssjd/shuangrenjian/F4.vue'
import Zt from '../views/ziyemian/ssjd/zttf/Zt.vue'

//新闻资讯子页面
import Xw1 from '../views/xinwen.vue'


//主题旅游子页面
import Cjy1 from '../views/ziyemian/ztly/cjy/Cjy1.vue'
import Xgy from '../views/ziyemian/ztly/gly/Xgy.vue'
import Gly from '../views/ziyemian/ztly/gly/Gly.vue'
import Hly from '../views/ziyemian/ztly/gly/Hly.vue'
import Fty from '../views/ziyemian/ztly/gly/Fty.vue'


//登录
import Login from '../views/Login.vue'
import Register from '../views/Register.vue'






Vue.use(VueRouter)

const routes = [
  {
    path: '/register',
    name: 'register',
    component: Register
  },
 
 
  {
    path: '/',
    name: 'login',
    component: Login
  },
//主题旅游子页面
{
  path: '/fty',
  name: 'fty',
  component: Fty
},
{
  path: '/hly',
  name: 'hly',
  component: Hly
},
{
  path: '/gly',
  name: 'gly',
  component: Gly
},
{
  path: '/xgy',
  name: 'xgy',
  component: Xgy
},
{
  path: '/cjy1',
  name: 'cjy1',
  component: Cjy1
},
{
  path: '/cjy1',
  name: 'cjy1',
  component: Cjy1
},
//新闻资讯子页面
{
  path: '/xw1',
  name: 'xw1',
  component: Xw1
},
//舒适酒店子页面
{
  path: '/zt',
  name: 'zt',
  component: Zt
},
{
  path: '/f4',
  name: 'f4',
  component: F4
},
{
  path: '/f3',
  name: 'f3',
  component: F3
},
{
  path: '/f2',
  name: 'f2',
  component: F2
},
{
  path: '/fone',
  name: 'fone',
  component: Fone
},

{
  path: '/srj',
  name: 'srj',
  component: Srj
},
{
  path: '/drj',
  name: 'drj',
  component: Drj
},
  //热门目的地子页面
  {
    path: '/fj',
    name: 'fj',
    component: Fj
  },
  {
    path: '/yn',
    name: 'yn',
    component: Yn
  },
  {
    path: '/dl',
    name: 'dl',
    component: Dl
  },
  {
    path: '/eh',
    name: 'eh',
    component: Eh
  },
  {
    path: '/yl',
    name: 'yl',
    component: Yl
  },
  {
    path: '/sc',
    name: 'sc',
    component: Sc
  },
  {
    path: '/hlg',
    name: 'hlg',
    component: Hlg
  },
  {
    path: '/jzg',
    name: 'Jzg',
    component: Jzg
  },
  {
    path: '/ls',
    name: 'Ls',
    component: Ls
  },
  //初始主页面
  {
    path: '/home',
    name: 'home',
    component: Home
  },
  {
    path: '/guanyuwomen',
    name: 'guanyuwomen',
    component: Guanyuwomen
  },
  {
    path: '/lianxiwomen',
    name: 'lianxiwomen',
    component: Lianxiwomen
  },
  {
    path: '/lianxiwomen',
    name: 'lianxiwomen',
    component: Lianxiwomen
  },
  {
    path: '/remenmudedi',
    name: 'remenmudedi',
    component: Remenmudedi
  },
  {
    path: '/shushijiudian',
    name: 'shushijiudian',
    component: Shushijiudian
  },
  {
    path: '/xnwenzixun',
    name: 'xnwenzixun',
    component: Xnwenzixun
  },
  {
    path: '/zhutilvyou',
    name: 'zhutilvyou',
    component: Zhutilvyou
  },
  { //这里是懒加载，暂时不要问，明天讲
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

const router = new VueRouter({
  mode:'history',
  base: process.env.BASE_URL,
  routes
})

export default router
