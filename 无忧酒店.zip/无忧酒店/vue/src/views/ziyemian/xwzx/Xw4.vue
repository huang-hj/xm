<template>
  <div class="home" data-spy="scroll">
   <div id="wrap_index"> <!-- 侧边导航 -->

<div class="class page-prev visible-xs visible-sm">
  <div class="close"></div>
  <div class="class-top">
    <form name="formsearch" action="/plus/search.php">
      <input type="hidden" name="kwtype" value="0">
      <input type="text" class="txt1" name="q" value="请输入关键字">
      <input type="submit" class="btn1" value="">
    </form>
  </div>
  <div class="class-m">
   <ul class="nnav">
            <li>
              <!-- <a href="../../../13097.html" class="ce">网站首页</a> -->
              <router-link to="/home" class="ce">网站首页</router-link>
            </li>
            <li class="menu_head">
              <router-link to="/guanyuwomen" class="ce">关于我们</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../zhutilvyou/Index.html" class="ce">主题旅游</a> -->
              <router-link to="/zhutilvyou" class="ce">主题旅游</router-link>
              <ul class="menu_body">
                <li>
                  <router-link to="/zhutilvyou" class="er"
                    >国内游</router-link
                  >
                </li>

                <li>
                  <router-link to="/cjy1" class="er"
                    >出境游</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../remenmudedi/Index.html" class="ce">热门目的地</a> -->
       <router-link to="/remenmudedi" class="ce">热门目的地</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/yn" class="er">云南</router-link>
                </li>

                <li>
                  <router-link to="/sc" class="er"
                    >四川</router-link
                  >
                </li>

                <li>
                  <router-link to="/fj" class="er">福建</router-link>
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../xinwenzixun/Index.html" class="ce">新闻资讯</a> -->
              <router-link to="/xnwenzixun" class="ce">新闻资讯</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../shushijiudian/Index.html" class="ce">舒适酒店</a> -->
              <router-link to="/shushijiudian" class="ce">舒适酒店</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/srj" class="er"
                    >双人间</router-link
                  >
                </li>

                <li>
                  <router-link to="/drj" class="er"
                    >单人间</router-link
                  >
                </li>

                <li>
                  <router-link
                    to="/zttf"
                    class="er"
                    >总统套房</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../lianxiwomen/Index.html" class="ce">联系我们</a> -->
              <router-link to="/lianxiwomen" class="ce">联系我们</router-link>

              <ul class="menu_body"></ul>
            </li>
          </ul>
  </div>
</div>
<div class="opacity2"></div>
<div id="header" class="head visible-lg visible-md">
  <div class="container-fluid">
    <div class="logo wow fadeInLeft col-md-3"><router-link to="../home"><img src="../../../../static/picture/logo.png"></router-link></div>
    <div class="col-md-9" style="height: 56px;">
      <div class="search col-md-3 wow fadeInRight" style="float: right;">
        <form name="formsearch" action="/plus/search.php">
          <input type="hidden" name="kwtype" value="0">
          <input class="txt1" type="text" name="q" placeholder="请输入关键字">
          <input class="btn1" type="submit" value="">
        </form>
      </div>
      <div class="col-md-9 nav wow fadeInDown navbar-nav nav_box" style="float: right; text-align: right;">
        <div class="yiji current"><router-link to="/home" >首页</router-link ></div>
        <div class="yiji"><router-link to="/guanyuwomen"><em>关于我们</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/zhutilvyou" ><em>主题旅游</em></router-link >
          <div class="libox">
             <router-link to="/zhutilvyou"><em>国内游</em></router-link>  <router-link to="/cjy1"><em>出境游</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/remenmudedi"><em>热门目的地</em></router-link >
          <div class="libox">
             <router-link to="/yn"><em>云南</em></router-link>  <router-link to="/sc"><em>四川</em></router-link>  <router-link to="/fj"><em>福建</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/xnwenzixun"><em>新闻资讯</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/shushijiudian"><em>舒适酒店</em></router-link >
          <div class="libox">
             <router-link to="/srj"><em>双人间</em></router-link>  <router-link to="/drj"><em>单人间</em></router-link>  <router-link to="/zt"><em>总统套房</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/lianxiwomen"><em>联系我们</em></router-link >
          <div style="display:none">
             </div>
        </div> </div>
    </div>
  </div>
</div>
<div id="molheader" class="visible-sm visible-xs">
  <div class="logomol"><router-link to="/home"><img src="../../../../static/picture/logo.png"></router-link></div>
  <div class="mol_navbutton"><img src="../../../../static/picture/menu.png"></div>
</div>
 
  <!-- pcbanner -->
  <div id="myCarousel1" class="carousel slide visible-md visible-lg">
    <div class="carousel-inner">
      <div class="item active"> <a><img src="../../../static/picture/b.jpg"><em></em></a> </div>
    </div>
  </div>
  <!-- 手机banner -->
  <div id="molbanner" class="visible-xs visible-sm">
    <div class="swiper-container swiper-banner">
      <ul class="swiper-wrapper banner-img">
        <li class="swiper-slide"><a class="pic"><img src="../../../static/picture/b.jpg"></a></li>
      </ul>
    </div>
  </div>
  <div class="wrap_page wrap_page1">
    <div class="page_content page_content1">
      <div class="newdtedit">
        <h2 class="tt">泰国还有那么一座岛叫大长岛，那么的美，你知</h2>
        <p class="time">2019-01-07 14:39</p>
        <p><p>
	一直隐藏着的大长岛，很多人都没听过这个名字。但看过《机械师2》的朋友不知道会不会有印象，杰森斯坦森去找杨紫琼时，虽然官宣说是丽贝岛，但实际抵达的那个离岛就是大长岛喔！ 趁现在这里还没有被过度开发，没人人人人人人海，赶紧来吧！</p>
<p>
	&nbsp;</p>
<p>
	大长岛的大概位于普吉岛西侧和甲米府东侧之间的攀牙湾海域。也是普吉附近最大的离岛了，被誉为安达曼海上最后一片&ldquo;世外桃源&rdquo;。</p>
<p>
	&nbsp;</p>
<p>
	它是因为狭长的外形而得名的，中文名又有音译为：瑶亚岛。岛上常住人口约8000人，</p>
<p>
	众所周知泰国是个有信仰的国度，但大长岛上特别的是，岛上居民大多数却信奉的是伊斯兰教。</p>
<p>
	&nbsp;</p>
<p>
	为什么要来大长岛</p>
<p>
	&nbsp;</p>
<p>
	因为这里还没有被完全的开发，所以完全避开了熙熙攘攘的旅游团队大军，还了岛上一片清净。相较于大长岛旁边的皮皮岛来说，这里可以说是人烟稀少啊~</p>
<p>
	&nbsp;</p>
<p>
	而且前往大长岛的距离又比皮皮岛近多了~</p>
<p>
	&nbsp;</p>
<p>
	在这个静瑟的小岛上，找家度假村，住上几天，悠闲放空。远离乌泱泱的人群，独享一片纯净的碧海蓝天，这不才是度假的精髓么！</p>
<p>
	&nbsp;</p>
<p>
	大长岛的最佳季节</p>
<p>
	&nbsp;</p>
<p>
	泰国属于热带季风气候。 一年三季，分别是热季（2月中旬至5月中旬）、雨季（5月下旬至10月中旬）和凉季（11月至次年2月中旬）。</p>
<p>
	&nbsp;</p>
<p>
	所以大长岛这边就建议是凉季来玩，天气最好了！毕竟海岛的风景美，都是靠美好的天气做衬托的~</p>
<p>
	大长岛怎么去</p>
<p>
	&nbsp;</p>
<p>
	岛上的酒店也不多，基本都是非常赞的五星级酒店（按国内标准衡量的话&hellip;）。不过因为不是开发完善的岛屿，所以岛上住宿的性价比是非常高的！</p>
<p>
	&nbsp;</p>
<p>
	类比五星级酒店的服务，一般酒店都会有自己的接送服务，只不过酒店的收费都会相对高一些。</p>
<p>
	&nbsp;</p>
<p>
	所以我在这里主要推荐乘坐公共交通工具的话，要怎么去呢？</p>
<p>
	&nbsp;</p>
<p>
	从普吉、甲米和攀牙出发的话，往返的船只分为渡轮和快艇两种。渡轮是比较大的船，船速缓而稳，船底可以停车；快艇就航行速度快，比较颠簸。</p>
<p>
	&nbsp;</p>
<p>
	例如：渡轮从普吉的到大长岛时长大概1小时，快艇约30分钟左右可以到达。</p>
<p>
	&nbsp;</p>
<p>
	Bang Rong 码头：为长尾船和快艇拼船两种，船次从早上7.50开始到下午17.30，约半小时发一次船。</p>
<p>
	快艇出发时间为：07:40 / 08:40 / 09:15 / 09:40 / 10:30 / 11:30 / 12:30 / 13:15 / 14:30 / 15:00 / 16:00 / 17:00 / 17:30 。</p>
<p>
	&nbsp;</p>
<p>
	TIP.个人建议你可以坐快艇，比较快，而且汽油味没有那么重，坐在里面也不会太晒。</p>

      </div>
      <div class="other clearfix"> <a href='16.html'>上一篇：如果你只给纽约一天</a> <a href='18.html'>下一篇：又到圣诞，今年的圣诞都想好怎么过了吗？</a>  <a href="javascript:history.go(-1)" class="return visible-md visible-lg">返回</a> </div>
    </div>
  </div>
</div>

<div class="footbg clearfix">
  <div class="footwrap col-md-11">
    <div class="logofriendly clearfix">
      <div class="footlogo col-sm-12 col-xs-12 col-md-2 block" data-move-x="-100px" style="opacity: 0; transform: translateX(-100px);"><img src="../../../static/picture/logo.png"></div>
      <div class="footnav col-sm-12 col-xs-12 col-md-8 block" data-move-x="-100px" style="opacity: 0; transform: translateX(-100px);">友情链接：        </div>
    </div>
    <div class="copyright clearfix">
      <p class="p1">Copyright &copy; 2020 某某旅游有限公司 版权所有
        </p>
      <!--<p class="p2">技术支持：<a href="http://www.dede58.cn/"> 58</a></p>--> 
    </div>
  </div>
  <div class="winxin col-md-1 visible-lg visible-md"> <i><img src="../../../static/picture/weixin.png"></i>
    <h2></h2>
  </div>
</div>

  </div>
</template>








<script>

export default {
  data(){
    return{
      
    }
  },
 
  
}
</script>
  
<style scoped>
@import "../../../static/css/animate.css";
@import "../../../static/css/style.css";
@import "../../../static/css/swiper-3.3.1.min.css";
@import "../../../static/css/bootstrap.min.css";

</style>