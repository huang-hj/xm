<template>
  <div class="home" data-spy="scroll">
   <div id="wrap_index"> <!-- 侧边导航 -->

<div class="class page-prev visible-xs visible-sm">
  <div class="close"></div>
  <div class="class-top">
    <form name="formsearch" action="/plus/search.php">
      <input type="hidden" name="kwtype" value="0">
      <input type="text" class="txt1" name="q" value="请输入关键字">
      <input type="submit" class="btn1" value="">
    </form>
  </div>
  <div class="class-m">
   <ul class="nnav">
            <li>
              <!-- <a href="../../../13097.html" class="ce">网站首页</a> -->
              <router-link to="/home" class="ce">网站首页</router-link>
            </li>
            <li class="menu_head">
              <router-link to="/guanyuwomen" class="ce">关于我们</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../zhutilvyou/Index.html" class="ce">主题旅游</a> -->
              <router-link to="/zhutilvyou" class="ce">主题旅游</router-link>
              <ul class="menu_body">
                <li>
                  <router-link to="/zhutilvyou" class="er"
                    >国内游</router-link
                  >
                </li>

                <li>
                  <router-link to="/cjy1" class="er"
                    >出境游</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../remenmudedi/Index.html" class="ce">热门目的地</a> -->
       <router-link to="/remenmudedi" class="ce">热门目的地</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/yn" class="er">云南</router-link>
                </li>

                <li>
                  <router-link to="/sc" class="er"
                    >四川</router-link
                  >
                </li>

                <li>
                  <router-link to="/fj" class="er">福建</router-link>
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../xinwenzixun/Index.html" class="ce">新闻资讯</a> -->
              <router-link to="/xnwenzixun" class="ce">新闻资讯</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../shushijiudian/Index.html" class="ce">舒适酒店</a> -->
              <router-link to="/shushijiudian" class="ce">舒适酒店</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/srj" class="er"
                    >双人间</router-link
                  >
                </li>

                <li>
                  <router-link to="/drj" class="er"
                    >单人间</router-link
                  >
                </li>

                <li>
                  <router-link
                    to="/zttf"
                    class="er"
                    >总统套房</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../lianxiwomen/Index.html" class="ce">联系我们</a> -->
              <router-link to="/lianxiwomen" class="ce">联系我们</router-link>

              <ul class="menu_body"></ul>
            </li>
          </ul>
  </div>
</div>
<div class="opacity2"></div>
<div id="header" class="head visible-lg visible-md">
  <div class="container-fluid">
    <div class="logo wow fadeInLeft col-md-3"><router-link to="../home"><img src="../../../../static/picture/logo.png"></router-link></div>
    <div class="col-md-9" style="height: 56px;">
      <div class="search col-md-3 wow fadeInRight" style="float: right;">
        <form name="formsearch" action="/plus/search.php">
          <input type="hidden" name="kwtype" value="0">
          <input class="txt1" type="text" name="q" placeholder="请输入关键字">
          <input class="btn1" type="submit" value="">
        </form>
      </div>
      <div class="col-md-9 nav wow fadeInDown navbar-nav nav_box" style="float: right; text-align: right;">
        <div class="yiji current"><router-link to="/home" >首页</router-link ></div>
        <div class="yiji"><router-link to="/guanyuwomen"><em>关于我们</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/zhutilvyou" ><em>主题旅游</em></router-link >
          <div class="libox">
             <router-link to="/zhutilvyou"><em>国内游</em></router-link>  <router-link to="/cjy1"><em>出境游</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/remenmudedi"><em>热门目的地</em></router-link >
          <div class="libox">
             <router-link to="/yn"><em>云南</em></router-link>  <router-link to="/sc"><em>四川</em></router-link>  <router-link to="/fj"><em>福建</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/xnwenzixun"><em>新闻资讯</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/shushijiudian"><em>舒适酒店</em></router-link >
          <div class="libox">
             <router-link to="/srj"><em>双人间</em></router-link>  <router-link to="/drj"><em>单人间</em></router-link>  <router-link to="/zt"><em>总统套房</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/lianxiwomen"><em>联系我们</em></router-link >
          <div style="display:none">
             </div>
        </div> </div>
    </div>
  </div>
</div>
<div id="molheader" class="visible-sm visible-xs">
  <div class="logomol"><router-link to="/home"><img src="../../../../static/picture/logo.png"></router-link></div>
  <div class="mol_navbutton"><img src="../../../../static/picture/menu.png"></div>
</div>
 
  <!-- pcbanner -->
  <div id="myCarousel1" class="carousel slide visible-md visible-lg">
    <div class="carousel-inner">
      <div class="item active"> <a><img src="../../../static/picture/b.jpg"><em></em></a> </div>
    </div>
  </div>
  <!-- 手机banner -->
  <div id="molbanner" class="visible-xs visible-sm">
    <div class="swiper-container swiper-banner">
      <ul class="swiper-wrapper banner-img">
        <li class="swiper-slide"><a class="pic"><img src="../../../static/picture/b.jpg"></a></li>
      </ul>
    </div>
  </div>
  <div class="wrap_page wrap_page1">
    <div class="page_content page_content1">
      <div class="newdtedit">
        <h2 class="tt">xx十大必游景点</h2>
        <p class="time">2019-01-07 14:38</p>
        <p><p>
	作为中国最早接触外界的城市，xx一直是中国繁华都市的代表，素有&ldquo;魔都&rdquo;之称。根据蚂蜂窝用户出行数据，文中为大家呈现了xx最受欢迎的十大景点。这些景点是xx的城市精华，适合初次造访想要&ldquo;打卡&rdquo;景点的游客。</p>
<p>
	&nbsp;</p>
<p>
	四通八达地铁、公交等公共交通，保证游客可轻松的往来于城区的各处景点。以外滩沿线为中心，游客可一同造访南京路步行街、陆家嘴、城隍庙、人民广场等xx代表景点。迪士尼乐园距离市区较远，客流量较大，最好单放一天游玩。</p>
<p>
	&nbsp;</p>
<p>
	外滩</p>
<p>
	&nbsp;</p>
<p>
	外滩是近代xx城市的起点，也收录着整座城市的精华。自1843年xx开埠（通商）以来，这里便成为了整座城市中最繁华的区域，时至今日。沿着宽阔的黄埔江，外滩一侧百年历史的万国建筑与对岸陆家嘴的新型都市交相辉映，转眼间展现着xx的过往与繁华。</p>
<p>
	&nbsp;</p>
<p>
	游览方式</p>
<p>
	&nbsp;</p>
<p>
	漫步外滩</p>
<p>
	大多数游客都会选择在外滩一侧赏景，因为这一侧可以拍到对岸陆家嘴鳞次栉比的摩天大楼，也是外滩标志性的取景区域。</p>
<p>
	&nbsp;</p>
<p>
	渡轮夜赏</p>
<p>
	外滩的渡轮分为两种，一种为从外滩往返对岸陆家嘴的跨江渡轮，一种为历时一个小时的游客观光渡轮。</p>
<p>
	&nbsp;</p>
<p>
	跨江渡轮：跨江渡轮从外滩的金陵东渡码头购票登船，船票价格为2元，历时10分钟左右，将游客送至对岸的陆家嘴。</p>
<p>
	&nbsp;</p>
<p>
	观光渡轮：观光渡轮从外滩的十六铺码头购票登船，票价从80-150元不等，区别在于是否含餐及赏景座位的区域。</p>
<p>
	&nbsp;</p>
<p>
	观景台俯瞰</p>
<p>
	在陆家嘴，有很多设有观景台的摩天大楼。这些观景台普遍位于百米高处，可从高空俯瞰外滩景致。设有观景台的摩天大楼包括 东方明珠、xx金茂大厦、环球金融中心、xx中心大厦。这其中最高的观景台位于xx中心大厦内，高546米。xx金茂大厦在340米处设有室外空中步道，百米高空的室外坐在摩天大楼的边缘想必会是场难忘的体验。</p>
<p>
	&nbsp;</p>
<p>
	露台餐厅、酒吧</p>
<p>
	在外滩一侧的欧式建筑顶端有很多高端餐厅及酒吧，这些地方是远离拥挤人群的最佳去处，同时还为你营造出一片欣赏陆家嘴景致的绝佳区域。餐厅的价格不菲、人均在人民币300+。</p>
<p>
	&nbsp;</p>
<p>
	人气露台餐厅</p>
<p>
	New Heights 新视角（西餐厅）</p>
<p>
	House of Roosevelt（烧烤餐厅）</p>
<p>
	M ON THE BUND（以欧洲菜为主）</p>
<p>
	deCanto（意大利餐厅）</p>
<p>
	Bar Rouge（露台酒吧）</p>
<p>
	&nbsp;</p>
<p>
	周边顺道游</p>
<p>
	&nbsp;</p>
<p>
	外滩步行即可到达南京路步行街、城隍庙、豫园等景点。还可以顺路去陆家嘴的xx迪士尼旗舰店逛逛，哪怕是不去迪士尼乐园，也可以在这里买到正版迪士尼纪念品。</p>

      </div>
      <div class="other clearfix"> <a href='14.html'>上一篇：普吉岛旅行不可不做的几件事！</a> <a href='16.html'>下一篇：如果你只给纽约一天</a>  <a href="javascript:history.go(-1)" class="return visible-md visible-lg">返回</a> </div>
    </div>
  </div>
</div>

<div class="footbg clearfix">
  <div class="footwrap col-md-11">
    <div class="logofriendly clearfix">
      <div class="footlogo col-sm-12 col-xs-12 col-md-2 block" data-move-x="-100px" style="opacity: 0; transform: translateX(-100px);"><img src="../../../static/picture/logo.png"></div>
      <div class="footnav col-sm-12 col-xs-12 col-md-8 block" data-move-x="-100px" style="opacity: 0; transform: translateX(-100px);">友情链接：        </div>
    </div>
    <div class="copyright clearfix">
      <p class="p1">Copyright &copy; 2020 某某旅游有限公司 版权所有
        </p>
      <!--<p class="p2">技术支持：<a href="http://www.dede58.cn/"> 58</a></p>--> 
    </div>
  </div>
  <div class="winxin col-md-1 visible-lg visible-md"> <i><img src="../../../static/picture/weixin.png"></i>
    <h2></h2>
  </div>
</div>
  </div>
</template>








<script>

export default {
  data(){
    return{
      
    }
  },
 
  
}
</script>
  
<style scoped>
@import "../../../static/css/animate.css";
@import "../../../static/css/style.css";
@import "../../../static/css/swiper-3.3.1.min.css";
@import "../../../static/css/bootstrap.min.css";

</style>