<template>
  <div class="home" data-spy="scroll">
   <div id="wrap_index"> <!-- 侧边导航 -->

<div class="class page-prev visible-xs visible-sm">
  <div class="close"></div>
  <div class="class-top">
    <form name="formsearch" action="/plus/search.php">
      <input type="hidden" name="kwtype" value="0">
      <input type="text" class="txt1" name="q" value="请输入关键字">
      <input type="submit" class="btn1" value="">
    </form>
  </div>
  <div class="class-m">
   <ul class="nnav">
            <li>
              <!-- <a href="../../../13097.html" class="ce">网站首页</a> -->
              <router-link to="/home" class="ce">网站首页</router-link>
            </li>
            <li class="menu_head">
              <router-link to="/guanyuwomen" class="ce">关于我们</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../zhutilvyou/Index.html" class="ce">主题旅游</a> -->
              <router-link to="/zhutilvyou" class="ce">主题旅游</router-link>
              <ul class="menu_body">
                <li>
                  <router-link to="/zhutilvyou" class="er"
                    >国内游</router-link
                  >
                </li>

                <li>
                  <router-link to="/cjy1" class="er"
                    >出境游</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../remenmudedi/Index.html" class="ce">热门目的地</a> -->
       <router-link to="/remenmudedi" class="ce">热门目的地</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/yn" class="er">云南</router-link>
                </li>

                <li>
                  <router-link to="/sc" class="er"
                    >四川</router-link
                  >
                </li>

                <li>
                  <router-link to="/fj" class="er">福建</router-link>
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../xinwenzixun/Index.html" class="ce">新闻资讯</a> -->
              <router-link to="/xnwenzixun" class="ce">新闻资讯</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../shushijiudian/Index.html" class="ce">舒适酒店</a> -->
              <router-link to="/shushijiudian" class="ce">舒适酒店</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/srj" class="er"
                    >双人间</router-link
                  >
                </li>

                <li>
                  <router-link to="/drj" class="er"
                    >单人间</router-link
                  >
                </li>

                <li>
                  <router-link
                    to="/zttf"
                    class="er"
                    >总统套房</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../lianxiwomen/Index.html" class="ce">联系我们</a> -->
              <router-link to="/lianxiwomen" class="ce">联系我们</router-link>

              <ul class="menu_body"></ul>
            </li>
          </ul>
  </div>
</div>
<div class="opacity2"></div>
<div id="header" class="head visible-lg visible-md">
  <div class="container-fluid">
    <div class="logo wow fadeInLeft col-md-3"><router-link to="../home"><img src="../../../../static/picture/logo.png"></router-link></div>
    <div class="col-md-9" style="height: 56px;">
      <div class="search col-md-3 wow fadeInRight" style="float: right;">
        <form name="formsearch" action="/plus/search.php">
          <input type="hidden" name="kwtype" value="0">
          <input class="txt1" type="text" name="q" placeholder="请输入关键字">
          <input class="btn1" type="submit" value="">
        </form>
      </div>
      <div class="col-md-9 nav wow fadeInDown navbar-nav nav_box" style="float: right; text-align: right;">
        <div class="yiji current"><router-link to="/home" >首页</router-link ></div>
        <div class="yiji"><router-link to="/guanyuwomen"><em>关于我们</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/zhutilvyou" ><em>主题旅游</em></router-link >
          <div class="libox">
             <router-link to="/zhutilvyou"><em>国内游</em></router-link>  <router-link to="/cjy1"><em>出境游</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/remenmudedi"><em>热门目的地</em></router-link >
          <div class="libox">
             <router-link to="/yn"><em>云南</em></router-link>  <router-link to="/sc"><em>四川</em></router-link>  <router-link to="/fj"><em>福建</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/xnwenzixun"><em>新闻资讯</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/shushijiudian"><em>舒适酒店</em></router-link >
          <div class="libox">
             <router-link to="/srj"><em>双人间</em></router-link>  <router-link to="/drj"><em>单人间</em></router-link>  <router-link to="/zt"><em>总统套房</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/lianxiwomen"><em>联系我们</em></router-link >
          <div style="display:none">
             </div>
        </div> </div>
    </div>
  </div>
</div>
<div id="molheader" class="visible-sm visible-xs">
  <div class="logomol"><router-link to="/home"><img src="../../../../static/picture/logo.png"></router-link></div>
  <div class="mol_navbutton"><img src="../../../../static/picture/menu.png"></div>
</div>
 
  <!-- pcbanner -->
  <div id="myCarousel1" class="carousel slide visible-md visible-lg">
    <div class="carousel-inner">
      <div class="item active"> <a><img src="../../../static/picture/b.jpg"><em></em></a> </div>
    </div>
  </div>
  <!-- 手机banner -->
  <div id="molbanner" class="visible-xs visible-sm">
    <div class="swiper-container swiper-banner">
      <ul class="swiper-wrapper banner-img">
        <li class="swiper-slide"><a class="pic"><img src="../../../static/picture/b.jpg"></a></li>
      </ul>
    </div>
  </div>
  <div class="wrap_page wrap_page1">
    <div class="page_content page_content1">
      <div class="newdtedit">
        <h2 class="tt">又到圣诞，今年的圣诞都想好怎么过了吗？</h2>
        <p class="time">2019-01-07 14:40</p>
        <p><p>
	香港地区</p>
<p>
	第一站：尖沙咀</p>
<p>
	The One：轻松小熊陪你过圣诞</p>
<p>
	&nbsp;</p>
<p>
	第二站：铜锣湾</p>
<p>
	皇室堡：轻松小熊波波池</p>
<p>
	时代广场：Snoopy Christmas</p>
<p>
	&nbsp;</p>
<p>
	第三站：旺角</p>
<p>
	朗豪坊：Line你埋嚟（喜欢你就来）</p>
<p>
	家乐坊：潮过圣诞！</p>
<p>
	&nbsp;</p>
<p>
	第四站：将军澳</p>
<p>
	東港城：Miffy圣诞乐园</p>
<p>
	&nbsp;</p>
<p>
	深圳地区</p>
<p>
	海雅缤纷城</p>
<p>
	欢乐海岸</p>
<p>
	&nbsp;</p>
<p>
	澳门地区</p>
<p>
	澳门teamlab</p>
<div>
	&nbsp;</div>

      </div>
      <div class="other clearfix"> <a href='17.html'>上一篇：泰国还有那么一座岛叫大长岛，那么的美，你知</a> <a href='19.html'>下一篇：在旅游过程中需要注意些什么</a>  <a href="javascript:history.go(-1)" class="return visible-md visible-lg">返回</a> </div>
    </div>
  </div>
</div>

<div class="footbg clearfix">
  <div class="footwrap col-md-11">
    <div class="logofriendly clearfix">
      <div class="footlogo col-sm-12 col-xs-12 col-md-2 block" data-move-x="-100px" style="opacity: 0; transform: translateX(-100px);"><img src="../../../static/picture/logo.png"></div>
      <div class="footnav col-sm-12 col-xs-12 col-md-8 block" data-move-x="-100px" style="opacity: 0; transform: translateX(-100px);">友情链接：        </div>
    </div>
    <div class="copyright clearfix">
      <p class="p1">Copyright &copy; 2020 某某旅游有限公司 版权所有
        </p>
      <!--<p class="p2">技术支持：<a href="http://www.dede58.cn/"> 58</a></p>--> 
    </div>
  </div>
  <div class="winxin col-md-1 visible-lg visible-md"> <i><img src="../../../static/picture/weixin.png"></i>
    <h2></h2>
  </div>
</div>
  </div>
</template>








<script>

export default {
  data(){
    return{
      
    }
  },
 
  
}
</script>
  
<style scoped>
@import "../../../static/css/animate.css";
@import "../../../static/css/style.css";
@import "../../../static/css/swiper-3.3.1.min.css";
@import "../../../static/css/bootstrap.min.css";

</style>